declare module "@salesforce/apex/LeaveRequstController.getMyLeaves" {
  export default function getMyLeaves(): Promise<any>;
}
declare module "@salesforce/apex/LeaveRequstController.getLeaveRequests" {
  export default function getLeaveRequests(): Promise<any>;
}
